# Dodge Rush — Build APK dari HP

## Cara paling mudah
1. Upload semua isi proyek ini ke repository GitHub.
2. Pastikan file `.github/workflows/build.yml` ikut ter-upload.
3. Buka tab **Actions** di repository.
4. Pilih **Build APK**.
5. Jalankan workflow dengan **Run workflow** jika belum berjalan otomatis.
6. Setelah selesai, buka hasil workflow dan bagian **Artifacts**.
7. Download **DodgeRush-APK** lalu ekstrak ZIP-nya.
8. Install `app-debug.apk` di HP.

Jika Android meminta izin instalasi dari sumber tersebut, aktifkan izin untuk aplikasi yang kamu gunakan untuk membuka APK.

Catatan: APK yang dihasilkan adalah debug APK untuk pengujian.
