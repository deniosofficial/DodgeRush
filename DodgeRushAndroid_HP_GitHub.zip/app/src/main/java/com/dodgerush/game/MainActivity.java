package com.dodgerush.game;

import android.app.*;
import android.os.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.view.*;
import android.content.*;
import java.util.*;

public class MainActivity extends Activity {
    public void onCreate(Bundle b){super.onCreate(b); getWindow().setFlags(1024,1024); setContentView(new GameView(this));}
}
class GameView extends View {
    Paint p=new Paint(1); Random r=new Random(); float playerX, playerY; int score=0, lives=3;
    ArrayList<float[]> rocks=new ArrayList<>(), coins=new ArrayList<>(); long last=0, start=0; boolean playing=true;
    GameView(Context c){super(c); p.setTypeface(Typeface.DEFAULT_BOLD); setFocusable(true); }
    protected void onSizeChanged(int w,int h,int ow,int oh){playerX=w/2f; playerY=h-150; start=System.currentTimeMillis();}
    protected void onDraw(Canvas c){
        int w=getWidth(),h=getHeight(); c.drawColor(Color.rgb(8,12,30));
        if(playing){
            float dt=(System.currentTimeMillis()-last)/16f; if(last==0)dt=1; last=System.currentTimeMillis();
            if(r.nextFloat()<0.045) rocks.add(new float[]{r.nextInt(Math.max(1,w-50))+25,-40});
            if(r.nextFloat()<0.025) coins.add(new float[]{r.nextInt(Math.max(1,w-50))+25,-40});
            float speed=5+score*.025f;
            p.setColor(Color.rgb(80,170,255)); c.drawCircle(playerX,playerY,28,p);
            p.setColor(Color.WHITE); c.drawCircle(playerX-10,playerY-5,5,p); c.drawCircle(playerX+10,playerY-5,5,p);
            p.setColor(Color.rgb(255,80,80));
            for(int i=rocks.size()-1;i>=0;i--){float[] a=rocks.get(i);a[1]+=speed*dt;c.drawCircle(a[0],a[1],22,p);
                if(Math.hypot(a[0]-playerX,a[1]-playerY)<45){rocks.remove(i);lives--; if(lives<=0)playing=false;}
                else if(a[1]>h+40)rocks.remove(i);}
            p.setColor(Color.YELLOW);
            for(int i=coins.size()-1;i>=0;i--){float[] a=coins.get(i);a[1]+=speed*.75f*dt;c.drawCircle(a[0],a[1],12,p);
                if(Math.hypot(a[0]-playerX,a[1]-playerY)<38){coins.remove(i);score+=10;}
                else if(a[1]>h+30)coins.remove(i);}
            p.setTextSize(42); c.drawText("Skor: "+score,25,55,p); c.drawText("❤️ "+lives,w-130,55,p);
            p.setTextSize(20); c.drawText("Geser jari untuk menggerakkan pesawat",25,h-25,p);
            invalidate();
        } else {
            p.setColor(Color.WHITE); p.setTextAlign(Paint.Align.CENTER);
            p.setTextSize(58); c.drawText("GAME OVER",w/2f,h/2f-70,p);
            p.setTextSize(34); c.drawText("Skor: "+score,w/2f,h/2f,p);
            p.setTextSize(25); c.drawText("Ketuk layar untuk main lagi",w/2f,h/2f+70,p);
            p.setTextAlign(Paint.Align.LEFT);
        }
    }
    public boolean onTouchEvent(android.view.MotionEvent e){
        if(e.getAction()==MotionEvent.ACTION_DOWN){if(!playing){score=0;lives=3;rocks.clear();coins.clear();playing=true;last=0;start=System.currentTimeMillis();invalidate();} playerX=e.getX();return true;}
        if(e.getAction()==MotionEvent.ACTION_MOVE){playerX=Math.max(30,Math.min(getWidth()-30,e.getX()));return true;}
        return true;
    }
}